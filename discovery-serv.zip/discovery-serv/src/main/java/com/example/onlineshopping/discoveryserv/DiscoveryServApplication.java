package com.example.onlineshopping.discoveryserv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscoveryServApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscoveryServApplication.class, args);
	}

}
