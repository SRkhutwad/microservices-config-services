INSERT INTO `inventory-service`.`inventory` (`id`, `sku_code`, `stock`) VALUES ('1', 'IPHONE_12_RED', '100');
INSERT INTO `inventory-service`.`inventory` (`id`, `sku_code`, `stock`) VALUES ('2', 'IPHONE_12_GREY', '0');
